
var ff = require('chrome-ext');

ff.attach(window);

